<?php

echo "<form method='POST' action='login_mhs.php'>";
    
    echo "NIM : <input type='text' name='username'>";
    echo "Pass : <input type='text' name ='password'>";

    echo "<input type='submit' value='Login'>";

echo "</form>"
    

?>