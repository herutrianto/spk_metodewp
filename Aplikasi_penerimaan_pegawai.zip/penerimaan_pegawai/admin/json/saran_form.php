<html>
	<body>
		<form method="post" action="saran.php">
			Topik <input type="text" name="topik"><br>
			Saran <textarea name="saran"></textarea><br>
			Rating <input type="text" name="rating"><br>
			<input type="submit" value="Proses">
		</form>
	</body>
</html>