<html>
	<body>
		<form method="post" action="pengaduan.php">
			NIM <input type="text" name="nim"><br>
			Topik <input type="text" name="topik"><br>
			Isi <textarea name="isi"></textarea><br>
			File <input type="text" name="file"><br>
			<input type="submit" value="Proses">
		</form>
	</body>
</html>